# W2 shared-file patches (human-readable copy of W2_shared_files.patch)

Easiest: from the repo root run `git apply --ignore-whitespace W2_shared_files.patch` (verified with `git apply --check` on a pristine copy of your zip).
If a hunk fails because another lane touched the same lines, apply the block below by hand: find the FIND text, replace it with the REPLACE text.


## backend/main.py

### M1 - imports

FIND (must match exactly once):
```
import data_access
from auth import (
    JWT_EXPIRES_HOURS,

```
REPLACE WITH:
```
import data_access
import snapshots  # W2
from starlette.concurrency import run_in_threadpool  # W2 (image re-encode runs off the event loop)
from auth import (
    JWT_EXPIRES_HOURS,

```

### M2 - init (one line, after the startup hook)

FIND (must match exactly once):
```
    data_access.sync_road_segments_cache()


# ---------------------------------------------------------------------------
# Helpers

```
REPLACE WITH:
```
    data_access.sync_road_segments_cache()


snapshots.init(app)  # W2: startup/shutdown hooks + /api/admin/snapshots/{publish,status}


# ---------------------------------------------------------------------------
# Helpers

```

### M3 - edit_event -> schedule

FIND (must match exactly once):
```
    data_access.record_audit(admin["sub"], admin["username"], "fest_updated", "event", event_id)
    return {"message": f"Event '{event_id}' updated."}
```
REPLACE WITH:
```
    data_access.record_audit(admin["sub"], admin["username"], "fest_updated", "event", event_id)
    snapshots.mark_dirty("schedule")  # W2
    return {"message": f"Event '{event_id}' updated."}
```

### M4 - verify_event -> schedule

FIND (must match exactly once):
```
    data_access.record_audit(admin["sub"], admin["username"], "fest_approved", "event", event_id)
    return {"message": f"Event '{event_id}' verified and now public."}
```
REPLACE WITH:
```
    data_access.record_audit(admin["sub"], admin["username"], "fest_approved", "event", event_id)
    snapshots.mark_dirty("schedule")  # W2 (also covers its poster: poster_url is embedded in schedule events)
    return {"message": f"Event '{event_id}' verified and now public."}
```

### M5 - reject_event -> schedule

FIND (must match exactly once):
```
    data_access.record_audit(admin["sub"], admin["username"], "fest_rejected", "event", event_id, {"reason": reason})
    return {"message": f"Event '{event_id}' rejected."}
```
REPLACE WITH:
```
    data_access.record_audit(admin["sub"], admin["username"], "fest_rejected", "event", event_id, {"reason": reason})
    snapshots.mark_dirty("schedule")  # W2 (rejecting a verified event must hide it)
    return {"message": f"Event '{event_id}' rejected."}
```

### M6 - request_changes -> schedule

FIND (must match exactly once):
```
    data_access.record_audit(admin["sub"], admin["username"], "fest_needs_changes", "event", event_id, {"notes": notes})
    return {"message": f"Event '{event_id}' sent back for changes."}
```
REPLACE WITH:
```
    data_access.record_audit(admin["sub"], admin["username"], "fest_needs_changes", "event", event_id, {"notes": notes})
    snapshots.mark_dirty("schedule")  # W2
    return {"message": f"Event '{event_id}' sent back for changes."}
```

### M7 - delete_event -> posters (marks posters AND schedule)

FIND (must match exactly once):
```
    data_access.record_audit(admin["sub"], admin["username"], "fest_deleted", "event", event_id)
    return {"message": f"Event '{event_id}' deleted."}
```
REPLACE WITH:
```
    data_access.record_audit(admin["sub"], admin["username"], "fest_deleted", "event", event_id)
    snapshots.mark_dirty("posters")  # W2: posters + schedule
    return {"message": f"Event '{event_id}' deleted."}
```

### M8 - upload_event_image -> WebP + posters

FIND (must match exactly once):
```
    _authorize_event_access(event_id, admin)

    content = await _read_upload_bounded(file)
    try:
        public_url, storage_path = data_access.upload_event_image_file(
            event_id,
            file.filename or "image",
            content,
            file.content_type or "application/octet-stream",
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e

    data_access.add_event_image(event_id, public_url, storage_path, is_poster)
    return {"url": public_url, "is_poster": is_poster}
```
REPLACE WITH:
```
    _authorize_event_access(event_id, admin)

    content = await _read_upload_bounded(file)
    try:
        # W2: always store WebP, <=1080 px wide, <=~150 KB, metadata stripped.
        # CPU-bound, so it runs in the threadpool, not on the event loop.
        content, content_type, filename, info = await run_in_threadpool(
            snapshots.optimize_upload, content, file.content_type, file.filename
        )
        public_url, storage_path = data_access.upload_event_image_file(
            event_id, filename, content, content_type
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    data_access.add_event_image(event_id, public_url, storage_path, is_poster)
    snapshots.mark_dirty("posters")  # W2: posters + schedule
    return {
        "url": public_url, "is_poster": is_poster,
        "bytes": info["bytes_out"], "width": info["width"], "height": info["height"],
    }
```

### M9 - delete_event_image -> posters

FIND (must match exactly once):
```
    if not data_access.delete_event_image(image_id, event_id):
        raise HTTPException(status_code=404, detail="Image not found.")
    return {"message": "Image deleted."}
```
REPLACE WITH:
```
    if not data_access.delete_event_image(image_id, event_id):
        raise HTTPException(status_code=404, detail="Image not found.")
    snapshots.mark_dirty("posters")  # W2: posters + schedule
    return {"message": "Image deleted."}
```

### M10 - close_segment -> closures

FIND (must match exactly once):
```
        raise HTTPException(status_code=404, detail=f"Segment '{seg_id}' not found")
    return {"message": f"Segment '{seg['name']}' closed. Routes will avoid this road."}
```
REPLACE WITH:
```
        raise HTTPException(status_code=404, detail=f"Segment '{seg_id}' not found")
    snapshots.mark_dirty("closures")  # W2
    return {"message": f"Segment '{seg['name']}' closed. Routes will avoid this road."}
```

### M11 - open_segment -> closures

FIND (must match exactly once):
```
        raise HTTPException(status_code=404, detail=f"Segment '{seg_id}' not found")
    return {"message": f"Segment '{seg['name']}' reopened."}
```
REPLACE WITH:
```
        raise HTTPException(status_code=404, detail=f"Segment '{seg_id}' not found")
    snapshots.mark_dirty("closures")  # W2
    return {"message": f"Segment '{seg['name']}' reopened."}
```

### M12 - upload_venue_menu -> menus (+ OPTIONAL WebP for menu images, 1600 px / 300 KB: dense menu text needs more than posters)

FIND (must match exactly once):
```
            public_url, storage_path = data_access.upload_menu_image_file(
                venue_id, file.filename or "menu", content, file.content_type or "image/jpeg"
            )
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e)) from e
        menu = data_access.upsert_menu(venue_id, date, public_url, storage_path, description, admin["sub"])
```
REPLACE WITH:
```
            # W2 (optional but recommended): WebP, <=1600 px, <=300 KB
            content, ctype, fname, _info = await run_in_threadpool(
                snapshots.optimize_upload, content, file.content_type, file.filename or "menu",
                1600, 300 * 1024,
            )
            public_url, storage_path = data_access.upload_menu_image_file(
                venue_id, fname, content, ctype
            )
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e)) from e
        menu = data_access.upsert_menu(venue_id, date, public_url, storage_path, description, admin["sub"])
        snapshots.mark_dirty("menus")  # W2
```

### M13 - delete_venue_menu -> menus

FIND (must match exactly once):
```
    if not deleted:
        raise HTTPException(status_code=404, detail="No menu found for that venue/date.")
    return {"message": "Menu deleted."}
```
REPLACE WITH:
```
    if not deleted:
        raise HTTPException(status_code=404, detail="No menu found for that venue/date.")
    snapshots.mark_dirty("menus")  # W2
    return {"message": "Menu deleted."}
```


## backend/data_access.py

### D1 - event image objects are immutable (uuid name): long browser/CDN cache

FIND (must match exactly once):
```
        client.storage.from_(EVENT_IMAGES_BUCKET).upload(
            storage_path, content, file_options={"content-type": content_type}
        )
```
REPLACE WITH:
```
        client.storage.from_(EVENT_IMAGES_BUCKET).upload(
            storage_path, content,
            file_options={"content-type": content_type, "cache-control": "31536000"},  # W2: name is unique per upload
        )
```


## frontend/src/api.js

### A1 - imports (cacheBundleResource becomes unused)

FIND (must match exactly once):
```
import { API_BASE } from './apiBase'
import { track } from './analytics/analyticsClient'
import { cacheBundleResource, getCachedBundleResource } from './offline/offlineBundle'

```
REPLACE WITH:
```
import { API_BASE } from './apiBase'
import { track } from './analytics/analyticsClient'
import * as snap from './data/dataClient'  // W2: snapshot-first reads
import { getCachedBundleResource } from './offline/offlineBundle'

```

### A2 - getLocations -> snapshot

FIND (must match exactly once):
```
export async function getLocations(category) {
  const q = category ? `?category=${encodeURIComponent(category)}` : ''
  try {
    const data = await getJSON(`/api/locations${q}`)
    // Only the unfiltered list is cached — every real caller in this app
    // (Home.jsx) always calls getLocations() with no category and filters
    // client-side, so caching a filtered subset under the same key would
    // silently corrupt the offline cache for everyone else. Guarded here
    // anyway rather than assumed, in case that ever changes.
    if (!category) cacheBundleResource('locations', data)
    return data
  } catch (err) {
    const cached = await getCachedBundleResource('locations')
    if (!cached) throw err
    return category
      ? cached.filter(l => (l.category || '').toLowerCase() === category.toLowerCase())
      : cached
  }
}
```
REPLACE WITH:
```
export function getLocations(category) {
  // W2: baked /data/locations.json -> live API -> last-known-good (see data/dataClient.js)
  return snap.getLocations(category)
}

```

### A3 - getLocation -> snapshot

FIND (must match exactly once):
```
export async function getLocation(id) {
  try {
    return await getJSON(`/api/locations/${id}`)
  } catch (err) {
    const cached = await getCachedBundleResource('locations')
    const found = cached?.find(l => l.id === id)
    if (found) return found
    throw err
  }
}
```
REPLACE WITH:
```
export function getLocation(id) {
  return snap.getLocation(id)
}

```

### A4 - getEvents + getEvent -> snapshot

FIND (must match exactly once):
```
export async function getEvents(fest) {
  const q = fest ? `?fest=${encodeURIComponent(fest)}` : ''
  try {
    const data = await getJSON(`/api/events${q}`)
    if (!fest) cacheBundleResource('events', data)
    return data
  } catch (err) {
    const cached = await getCachedBundleResource('events')
    if (!cached) throw err
    return fest ? cached.filter(e => (e.fest || '').toLowerCase() === fest.toLowerCase()) : cached
  }
}

export async function getEvent(id) {
  try {
    return await getJSON(`/api/events/${id}`)
  } catch (err) {
    const cached = await getCachedBundleResource('events')
    const found = cached?.find(e => e.id === id)
    if (found) return found
    throw err
  }
}
```
REPLACE WITH:
```
export function getEvents(fest) {
  return snap.getSchedule({ fest })
}

export function getEvent(id) {
  return snap.getEvent(id)
}

```

### A5 - getRoadSegments -> snapshot

FIND (must match exactly once):
```
export async function getRoadSegments() {
  try {
    const data = await getJSON('/api/road-segments')
    cacheBundleResource('road-segments', data)
    return data
  } catch (err) {
    const cached = await getCachedBundleResource('road-segments')
    if (cached) return cached
    throw err
  }
}
```
REPLACE WITH:
```
export function getRoadSegments() {
  return snap.getClosures()
}

```

### A6 - getGraph -> snapshot (W1 owns graph loading: if W1 already rewrote getGraph, keep W1's version and have it call snap.getGraph())

FIND (must match exactly once):
```
export async function getGraph() {
  const data = await getJSON('/api/graph')
  cacheBundleResource('graph', data)
  return data
}
```
REPLACE WITH:
```
export function getGraph() {
  return snap.getGraph()
}

```

### A7 - getVenueMenu + eventQrUrl -> snapshot

FIND (must match exactly once):
```
export function getVenueMenu(venueId, date) {
  const q = date ? `?date=${encodeURIComponent(date)}` : ''
  return getJSON(`/api/locations/${encodeURIComponent(venueId)}/menu${q}`)
}

export function eventQrUrl(id) {
  return `${API_BASE}/api/events/${id}/qr`
}
```
REPLACE WITH:
```
export function getVenueMenu(venueId, date) {
  return snap.getVenueMenu(venueId, date)   // rejects with .status === 404 when no menu, as before
}

export function eventQrUrl(id) {
  return snap.qrUrl(id)   // bucket copy when published, else the backend endpoint
}

```


## frontend/src/components/BootGate.jsx

### B1 - import

FIND (must match exactly once):
```
import { checkHealth, getGraph, getRoadSegments, getLocations } from '../api'

```
REPLACE WITH:
```
import { checkHealth, getGraph, getRoadSegments, getLocations } from '../api'
import { getSchedule } from '../data/dataClient'  // W2

```

### B2 - seedEventsCache: stop hitting /api/events directly on every boot

FIND (must match exactly once):
```
function seedEventsCache() {
  const base = import.meta.env.VITE_API_BASE || 'http://127.0.0.1:8000'
  fetch(`${base}/api/events`)
    .then((r) => (r.ok ? r.json() : null))
    .then((data) => {
      if (!Array.isArray(data) || data.length === 0) return
      try {
        localStorage.setItem(EVENTS_CACHE_KEY, JSON.stringify({ data, ts: Date.now() }))
      } catch { /* storage quota — silently ignore */ }
    })
    .catch(() => { /* non-fatal — EventsList will fetch normally */ })
}

// Task 1 (offline support) — warms the on-device cache offline routing
// needs (see offline/db.js, offline/offlineBundle.js, api.js) the moment
// the backend is first confirmed reachable, rather than waiting on
// Home.jsx's own mount to call getLocations()/getRoadSegments(). Each of
// these already caches itself on success (see api.js) — this just makes
// sure that happens even if the user's very first session lands on a
// route other than Home (an EventPage deep link, say) or ends before
// Home.jsx gets there itself.
```
REPLACE WITH:
```
function seedEventsCache() {
  // W2: schedule snapshot instead of a direct backend call
  getSchedule()
    .then((data) => {
      if (!Array.isArray(data) || data.length === 0) return
      try {
        localStorage.setItem(EVENTS_CACHE_KEY, JSON.stringify({ data, ts: Date.now() }))
      } catch { /* storage quota — silently ignore */ }
    })
    .catch(() => { /* non-fatal — EventsList will fetch normally */ })
}

```


## frontend/src/pages/EventPage.jsx

### E1 - gallery thumbs lazy

FIND (must match exactly once):
```
                  alt={`Event photo ${i + 1}`}
                  className="event-photo-item"
                  onClick={() => setLightboxIdx(i)}
```
REPLACE WITH:
```
                  alt={`Event photo ${i + 1}`}
                  className="event-photo-item"
                  loading="lazy"
                  decoding="async"
                  onClick={() => setLightboxIdx(i)}
```

### E2 - QR lazy

FIND (must match exactly once):
```
            alt={`QR for ${event.name}`}
            className="event-qr-img"
          />
```
REPLACE WITH:
```
            alt={`QR for ${event.name}`}
            className="event-qr-img"
            loading="lazy"
            decoding="async"
          />
```


## backend/.env.example  (append at end of file)
```
# --- Static snapshots (W2) -------------------------------------------------
# All optional; defaults shown. Reuses SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY above.
SNAPSHOT_ENABLED=true
SNAPSHOT_BUCKET=snapshots
SNAPSHOT_CACHE_SECONDS=60
SNAPSHOT_DEBOUNCE_SECONDS=5
SNAPSHOT_MAX_WAIT_SECONDS=30
SNAPSHOT_PUBLISH_ON_STARTUP=false
SNAPSHOT_MENU_DAYS_AHEAD=14
SNAPSHOT_INCLUDE_CONTACT_INFO=false
SNAPSHOT_IMAGE_MAX_WIDTH=1080
SNAPSHOT_IMAGE_TARGET_KB=150
```

## frontend/.env.example  (append at end of file)
```
# Static snapshots (W2): public Supabase Storage bucket `snapshots`. No key needed: it is public read.
VITE_SNAPSHOT_BASE_URL=https://bsucvxhvshvrwouupbct.supabase.co/storage/v1/object/public/snapshots
# Optional: >0 appends ?b=<time bucket> to live-snapshot URLs (bounds staleness if the CDN is slow to refresh)
# VITE_SNAPSHOT_BUCKET_SECONDS=30
```

## frontend/vite.config.js  (merge chat, not me)
Concatenate `import snapshotCaching from './pwa/runtimeCaching.snapshots.js'` and put `...snapshotCaching` FIRST in `runtimeCaching`, before the existing `supabase-images` entry (that entry matches every *.supabase.co/storage/ URL).
